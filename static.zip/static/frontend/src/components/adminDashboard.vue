<template>

        <h1> Welcome Boss </h1>

</template>

<script>


export default {
    name: 'adminDashboard'
}

</script>