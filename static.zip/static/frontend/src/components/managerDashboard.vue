<template>

    <h1> Welcome Manager </h1>

</template>

<script>

export default {
    name: 'managerDashboard'
}
</script>